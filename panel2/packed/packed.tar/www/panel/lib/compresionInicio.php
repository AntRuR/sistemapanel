<?php //á

ob_start();
ob_implicit_flush(0);

?>