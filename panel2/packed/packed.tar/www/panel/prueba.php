<?php //á


$return = eval("echo \"llora2\";");
echo "<br>";
echo ($return)?1:0;

?>