<?php

$html_title			="Panel de Control";

$meta_title			="titulo meta";
$meta_descripcion	="descripcion meta";
$meta_keyword		="keyword meta";


$DIR_IMG_TEMP = "/images_temp";


$HTML_ALL_INICIO    = '
<div id="div_allcontent" >
	<div id="div_contenedor"  >
		';
		
$HTML_MAIN_INICIO   = '
		<div class="contenido_principal"   >';
		
$HTML_MAIN_FIN 		= '
		</div>';		

$HTML_ALL_FIN		= '
	</div>
</div>';

$c_interfaceLang='ES';


//FTP

$httpfiles      = "http://www.casalindaperu.com"; // Ruta web del directorio de ficheros
$ftp_files_host = 'www.casalindaperu.com';			 // ip para la conexi�n ftp de ficheros
$ftp_files_user = 'casalind';			 // usuario ftp ficheros
$ftp_files_pass = 'd3nRbtb413';				 // clave ftp ficheros
$ftp_files_root = "/www/";	 			 // directorio principal


$USU_IMG_DEFAULT = "img/usuario_black_103x103.jpg";

?>