<?php //á
 
	include("lib/playmemory.php");
?>