function $v(a){ return $(a).value; }
function $1(a){ $(a).style.display=''; }
function $0(a){ $(a).style.display='none'; }

