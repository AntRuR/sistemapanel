<?php //á
/* */
$Open=($_COOKIE['admin']=='1' and $vars['GENERAL']['mostrar_toolbars']=='1')?1:0;
?>
<?php
$vars['GENERAL']['BG_COLOR_4']="CCCCCC";
$BG_COLOR_3_OPP=oppColour($vars['GENERAL']['BG_COLOR_3']);
$BG_COLOR_4_OPP=oppColour($vars['GENERAL']['BG_COLOR_4']);
?>
<style>
.mooeditable-ui-dialog .dialog-content * { float:none;}
.bloque_titulo a { color:#<?php echo $BG_COLOR_3_OPP;?>; }
.foot a { color:#<?php echo $BG_COLOR_3_OPP;?>; margin-right:5px; }
.bloque_titulo { background-color:#<?php echo $vars['GENERAL']['BG_COLOR_3'];?>; color:#<?php echo $BG_COLOR_3_OPP;?>;  }
.menus a , ul.ul_menus li{ padding:2px <?php echo $menu_padding_lados;?> }
ul.ul_menus li:hover a,
ul.ul_menus li:hover,
.menus a:hover,
.menus a.selected,
ul.ul_menus li.selected,
ul.ul_menus li.selected a
{ background-color:#<?php echo $vars['GENERAL']['BG_COLOR_3'];?>; color:#<?php echo $BG_COLOR_3_OPP;?>;  }
.segunda_barra {
background-color:#<?php echo $vars['GENERAL']['BG_COLOR_4'];?>;
color:#<?php echo $BG_COLOR_4_OPP;?>;
}
.open_toolbar { float:right;font-size:9px; color:#CCCCCC; }
.open_toolbar:hover { color:#000000; } 
#div_contenedor { background:#FFFFFF; }
</style>
<script>
window.addEvent('domready',function(){	
	$('div_contenedor').setStyles({'background':'none'});
});
</script>
<?php 
//prin($_SESSION);
//prin($_COOKIE);
//prin($Open);
//prin($Local);
//if(1){ 
if( ( $Open or $Local==1 ) ){ 
if((strpos($_SERVER['SCRIPT_NAME'], "login.php")===false) and ($vars['GENERAL']['mostrar_toolbars']==1)){
include("maquina_opciones.php");
}
} 

?>
<script>
function edit_init(se,na,va){
new Request({url:"lib/edit_ini.php",method:'post',data:{seccion:se,name:na,value:va},onSuccess:function(eee){location.reload(true);}}).send();
}
</script>
<div>
<?php

$sn=explode("/",$_SERVER['SCRIPT_NAME']);
$script_name=str_replace(".php","",$sn[sizeof($sn)-1]);

$menus_d[] = "<a style='position:relative;float:right;margin-bottom:-19px;' href='$url_publica' target='_top' ><span class='menu_ai'></span><span class='menu_ad'></span><span class='menu_bi'></span><span class='menu_bd'></span>$url_publica</a>";


if($_COOKIE['admin']=='1' and !( $Open ) ){
$menus_d[] =  "<a href='#' style='position:relative;float:right;margin-bottom:-19px;' rel='nofollow' onclick=\"javascript:edit_init('GENERAL','mostrar_toolbars','1');return false;\"><span class='menu_ai'></span><span class='menu_ad'></span><span class='menu_bi'></span><span class='menu_bd'></span>abrir toolbar</a>";

} 

if($Open or $Local==1){

$menus_d[] = "<a ". (($script_name=="maquina")?"class='selected'":"") ." style='position:relative;float:right;margin-bottom:-19px;' href='maquina.php' ><span class='menu_ai'></span><span class='menu_ad'></span><span class='menu_bi'></span><span class='menu_bd'></span>desarrollo</a>";

if($Local==1){

$menus_d[] = "<a ". (($script_name=="maquina")?"class='selected'":"") ." style='position:relative;float:right;margin-bottom:-19px;background-color:black;font-weight:bold;color:white;' href='http://".$_SERVER['SERVER_NAME']."/sistemapanel/panel' ><span class='menu_ai'></span><span class='menu_ad'></span><span class='menu_bi'></span><span class='menu_bd'></span>".$vars['GENERAL']['factory']."</a>";

}

}

if( $VALIDAR_SESION!='' and $_SESSION['usuario_id']!='' ){
	$menus_d[] = "<a style='position:relative;float:right;margin-bottom:-19px;' href='salir.php'><span class='menu_ai'></span><span class='menu_ad'></span><span class='menu_bi'></span><span class='menu_bd'></span>salir</a>";
	$menus_d[] = "<a style='position:relative;float:right;margin-bottom:-19px;text-decoration:none;font-weight:bold;background-color:#FFFFFF;color:#000000 !important;'>". select_dato($sesion_login,$tabla_sesion,"where $sesion_id='".$_SESSION['usuario_id']."'") ."</a>";
}
if( $VALIDAR_SESION!='' and $_SESSION['usuario_id']!='' or $Open){

	$menus_d[] = "<a ". (($_GET['tab']=="estadisticas")?"class='selected'":"") ." style='position:relative;float:right;margin-bottom:-19px;' href='tools.php?tab=estadisticas'><span class='menu_ai'></span><span class='menu_ad'></span><span class='menu_bi'></span><span class='menu_bd'></span>estadísticas</a>";

	$menus_d[] = "<a ". (($_GET['tab']=="feedback")?"class='selected'":"") ."  title='Reporte de errores, Ayúdenos a mejorar' style='position:relative;float:right;margin-bottom:-19px;' href='tools.php?tab=feedback'><span class='menu_ai'></span><span class='menu_ad'></span><span class='menu_bi'></span><span class='menu_bd'></span>feedback</a>"; 
		
}	
list($titulo_strong,$dos)=explode("::",$vars['GENERAL']['html_title']);
echo "<div class='menus' >";
if($SERVER['browser']!='IE7'){
echo "<b style='text-transform:uppercase;'>".$titulo_strong."</b>";
}
//echo implode("<span class='pale' style='float:right;margin-bottom:-15px;'>|</span>",$menus_d);
echo implode("",$menus_d);
echo "</div>";

?>
<?php 


if(file_exists($img_logo)){
if(trim($img_logo)!=''){ 
?><a href="./" ><img src="<?php echo $img_logo?>" align="absmiddle" style="float:left;margin-top:10px;" border="0"  /></a><?php 
} } ?>
<a href="./" class="link_header" style="color:#<?php echo $BG_COLOR_3;?>;
text-shadow: 1px 1px 1px #000; 
letter-spacing:<?php echo $titulo_letter_spacing?>;font-size:<?php echo $titulo_font_size;?>; " ><?php echo $html_titulo;?></a>
<?php 
?>
&nbsp;
</div>
<?php /* */ ?>
<?php

$tablas_creadas=array();
$sql = "show tables";
$result=mysql_query($sql,$link);
$total=mysql_num_rows($result);
if($total>0){
	while ($row = mysql_fetch_row($result)){
			$tablas_creadas[] = $row[0];
	}
}
$menus=array();
$menus_1=array();
$menus_2=array();
//echo "<pre>"; print_r($objeto_tabla); echo "</pre>";
//prin($Open);
foreach($objeto_tabla as $item){

	if($SERVER['ARCHIVO']==$item['archivo'].".php"){
	$this_grupo=$item['grupo'];
	}
	if( $item['menu']=='1' or ($Open=='1' and $item['archivo_hijo']=='' and $item['menu_label']!='' ) ){

		if(file_exists($DIR_CUSTOM.$item['archivo'].".php") and in_array($item['tabla'],$tablas_creadas) and ($saved[$item['me']]['live']=='1') ){
			$bbgg = ( !( ($script_name==$item['archivo']) or ($script_name==$item['archivo_hijo']) ) and ($item['menu']!='1') )?1:0;
			if($bbgg){ $BBB[]=$item['me']; }
			$mmm ="<li ". ((($script_name==$item['archivo']) or ($script_name==$item['archivo_hijo']))?"class='selected'":"") ." 
			style='padding-top:0px;padding-bottom:0px;" . ( ($bbgg)?"background-color:".$BGCOLOR_DESARROLLO.";":"") . "'>";
			$mmm .="<a style='". ( ($bbgg)?"background-image:none;":"") . "padding-top:2px;padding-bottom:2px;" . ( ( !( ($script_name==$item['archivo']) or ($script_name==$item['archivo_hijo']) ) and ($item['menu']!='1') )?"color:#000000;":'') . "' href='".$DIR_CUSTOM.$item['archivo'].".php' 
			 >".$item['menu_label'].$item['archivo_padre'];
			$nume=contar($item['tabla'],"");
			$mmm.=" <span class='numero'>($nume)</span>";
			$mmm.="</a>";
			$mmm.="<span class='menu_ai'></span><span class='menu_ad'></span>";
			$mmm.="<span class='menu_bi'></span><span class='menu_bd'></span>";
			/*
			if($_COOKIE['admin']=='1'){
			$submenus[]=array("url"=>"maquina.php?me=".$item['me'],"label"=>"devel");
			}
			*/
			/*
			$subnum=sizeof($submenus);
			if($subnum>0){
			$mmm.=($vars['GENERAL']['ESTILO_2']=='1')?"<div class='submenu' style='right:-100%;top:0px;'>":"<div class='submenu' style='bottom:-". (15*$subnum) ."px;'>";
			foreach($submenus as $submenu){
			$mmm.="<a href='".$submenu['url']."'>".$submenu['label']."</a>";
			}
			$mmm.="</div>";
			}
			unset($submenus);
			*/
			$mmm.="</li>";
			
			if(  !( ($script_name==$item['archivo']) or ($script_name==$item['archivo_hijo']) ) and ($item['menu']!='1') ){
			$menus_2[]=array('h'=>$mmm,'g'=>$item['grupo']);
			} else {
			$menus_1[]=array('h'=>$mmm,'g'=>$item['grupo']);
			}

			$menus[]=array('h'=>$mmm,'g'=>$item['grupo']);
			if(!in_array($item['grupo'],$grupi)){
				$grupi[]=$item['grupo'];
				if( ($item['grupo']!='sistema') or ($item['grupo']=='sistema' and $Open )){
					if(trim($item['grupo'])!='' ){
					$GrupLi[]="<a style='float:right;opacity:0.9;' id='idg_".$item['grupo']."' ". (($item['grupo']=='sistema')?"class='admincc'":'') ." href='".$DIR_CUSTOM.$item['archivo'].".php'>
					<span class='menu_ai'></span><span class='menu_ad'></span>
					".strtoupper($item['grupo'])."</a>";
					}
				}
			}		

		}
	}
}
?>
<?php
if(sizeof($GrupLi)>0){
echo "<div class='menus' style='margin-bottom:-5px;'>";
echo implode("",$GrupLi);
echo "</div>";
}
//echo implode("<span class='pale'>|</span>",$menus);
//$menus=array_merge($menus_1,$menus_2);
$htmlmenu ='';
if(sizeof($menus)>0){
if($_GET['tab']==''){
$htmlmenu .='<ul class="ul_menus">';
foreach($menus as $menn){
if($menn['g']==$this_grupo or $SERVER['ARCHIVO']=="maquina.php"){
$htmlmenu .=$menn['h'];
}
}
$htmlmenu .='</ul>';
$htmlmenu .="<script>if(\$('idg_".$this_grupo ."')){\$('idg_".$this_grupo ."').addClass('selected');}</script>";
}
echo $htmlmenu;
} else {
echo "<style> .div_bloque_cuerpo { width:100%; } </style>";
}
?>
<style>
/*
.linksgrupos { clear:both; }
.linksgrupos a { color:#FF0000;}
.linksgrupos a.admincc { color:pink;}
.linksgrupos a.seleccc { color:#000;}
.linksgrupos a:hover { color:#000;}
*/
</style>