<?php //á

//$_POST['indice']="bloqueado";
//$_POST['valor']="1";
//$_POST['me']="PRODUCTOS_ITEMS";

$indice= $_POST['indice'];

$valor = $_POST['valor'];


$bloque_separacion="/******************************************************************************************************************************************************/";

$file_tablas_a=file("config/tablas.php");
foreach($file_tablas_a as $bt){
if(trim($bt)!=""){
$file_tablas_a2[]=str_replace(array("\t",$bloque_separacion,"&nbsp;"),array("  ",""," "),$bt);
}
}
$file_tablas=str_replace(array("<?php","?>"),array("",""),implode("",$file_tablas_a2));
$bloques_tablas=explode(";",$file_tablas);
//echo "<pre>"; print_r($objeto_tabla); echo "</pre>";
foreach($bloques_tablas as $i=>$blota){
	if(!(strpos($blota,"objeto_tabla['".$_POST['me']."']")===false)){
		//echo $objeto_tabla[$_POST['me']];
		//if(isset($objeto_tabla[$_POST['me']])){
			$blota_A=explode(",",$blota);
			//echo "<pre>"; echo print_r($blota_A); echo "</pre>";
			foreach($blota_A as $y=>$blA){
				if(!(strpos($blA,"'$indice'")===false)){
					//echo $blA;
					$blaA2 = explode("=>",trim($blA));
					$yyy = "\n".$blaA2[0]."=>'".$_POST['valor']."'";
					$blota_A[$y]= $yyy;
					//echo "<pre>"; echo print_r($blaA2); echo "</pre>";
					
				}
			}
			$blota=implode(",",$blota_A);
			//echo "<pre>".$blota."</pre>";
			$bloques_tablas[$i]=$blota;
		//}
	}
}

$filetxt="<?php \n".$bloque_separacion."\n\n\n".implode(";\n\n\n".$bloque_separacion."\n\n\n",$bloques_tablas)."\n ?>";

@unlink("config/tablas_copy.php");
//rename("config/tablas.php","config/tablas_copy.php");

$f1=fopen("config/tablas.php","w+");
fwrite($f1,$filetxt);
fclose($f1); 	

?>