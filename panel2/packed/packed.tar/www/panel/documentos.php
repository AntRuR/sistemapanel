<?php
//prin($vars);
?>
<div>
<h1 style="font-weight:bold; clear:left;">DOCUMENTOS</h1></div>

<ul>
<li><a href="https://tickets.hostgator.com" target="_blank">HOSTGATOR TICKET</a> (guillermolozan@gmail.com|platano)</li>

<br />
<ul>
<li><a href="http://www.google.com/a/cpanel/standard/new" target="_blank">INCRIBIR EN GOOGLE APPS STANDARD</a> (Walter|Távara|guillermolozan@gmail.com|2614506|||administrador|<?php echo $vars['REMOTE_FTP']['ftp_files_pass'];?>)</li>
<li><a href="maquina.php?accion=crear_archivo_verificacion" >crear archivo de verificación de dominio, redirección de email e imágen para email</a> (archivo:googlehostedservice.html, contenido:googleb286641876ac8feb)</li>
<li><a href="<?php echo $vars['REMOTE']['url_publica']."/googlehostedservice.html";?>" target="_blank">verificar dominio</a></li>
<li>Adicionalmente : Personalización del dominio [ General,Apariencia ( imagen de gif o png de 143x159) ] </li>
<li><a href="https://www.google.com/a/<?php echo $vars['REMOTE_FTP']['ftp_files_host'];?>" target="_blank">https://www.google.com/a/<?php echo $vars['REMOTE_FTP']['ftp_files_host'];?></a></li>
<li><a href="http://mail.google.com/a/<?php echo $vars['REMOTE_FTP']['ftp_files_host'];?>" target="_blank">http://mail.google.com/a/<?php echo $vars['REMOTE_FTP']['ftp_files_host'];?></a></li>
<li><a href="http://<?php echo $vars['REMOTE_FTP']['ftp_files_host'];?>/email" target="_blank">http://<?php echo $vars['REMOTE_FTP']['ftp_files_host'];?>/email</a></li>

<li><a href="maquina.php?accion=enviar_email_password&gmail=1&panel=1" >Enviar email con password ( FTP | PANEL | GMAIL )</a></li>
<li><a href="maquina.php?accion=enviar_email_password&gmail=1&panel=0" >Enviar email con password ( FTP | GMAIL )</a></li>
<li><a href="maquina.php?accion=enviar_email_password&gmail=0&panel=1"  >Enviar email con password ( FTP | PANEL )</a></li>
<br />
<li><a href="http://<?php echo $vars['REMOTE_FTP']['ftp_files_host'];?>:2082" target="_blank">CPANEL</a> (<?php echo $vars['REMOTE_FTP']['ftp_files_user'];?>|<?php echo $vars['REMOTE_FTP']['ftp_files_pass'];?>) crear [panel|guillermo|lozan159357] </li>
<br />

<li>Herramientas Google</li>

<li><a href="https://www.google.com/analytics/settings/?hl=es" target="_blank">GOOGLE ANALYTICS</a></li>

<li><a href="http://www.google.com/insights/search/#" target="_blank">GOOGLE INSIGHT</a></li>

<li><a href="http://www.google.com/wave" target="_blank">GOOGLE WAVE</a></li>

<br />
<li><a href="http://mail.google.com/support/bin/answer.py?hl=es&ctx=mail&answer=12103">CONFIGURACION DE GMAIL PARA CLIENTES POP</a>POP3|pop.gmail.com|smtp.gmail.com|(SMTP)465|(POP3)995</li>
<li><a href="https://secure.hostgator.com/billing/" target="_blank">HOSTGATOR BILLING</a> (guillermolozan@gmail.com|platano)</li>
<li><a href="http://forums.hostgator.com/" target="_blank">HOSTGATOR FORUM</a> (guillermolozan|platano)</li>
</ul>
<br />
<h2>CPANEL X</h2>
<li>
<a href="http://<?php echo $vars['REMOTE_FTP']['ftp_files_user'];?>:<?php echo $vars['REMOTE_FTP']['ftp_files_pass'];?>@<?php echo $vars['REMOTE_FTP']['ftp_files_host'];?>2082/frontend/x/index.html" target="_blank">CPANEL</a> | 
<a href="http://<?php echo $vars['REMOTE_FTP']['ftp_files_user'];?>:<?php echo $vars['REMOTE_FTP']['ftp_files_pass'];?>@<?php echo $vars['REMOTE_FTP']['ftp_files_host'];?>:2082/frontend/x/sql/index.html" target="_blank">DATABASE</a> | 
<a href="http://<?php echo $vars['REMOTE_FTP']['ftp_files_user'];?>:<?php echo $vars['REMOTE_FTP']['ftp_files_pass'];?>@<?php echo $vars['REMOTE_FTP']['ftp_files_host'];?>:2082/frontend/x/cron/advcron.html" target="_blank">CRON</a> | 
<a href="http://<?php echo $vars['REMOTE_FTP']['ftp_files_user'];?>:<?php echo $vars['REMOTE_FTP']['ftp_files_pass'];?>@<?php echo $vars['REMOTE_FTP']['ftp_files_host'];?>:2082/3rdparty/phpMyAdmin/index.php" target="_blank">PHPMYADMIN</a> 
</li>

<h2>CPANEL RVBLUE</h2>
<li>
<a href="http://<?php echo $vars['REMOTE_FTP']['ftp_files_user'];?>:<?php echo $vars['REMOTE_FTP']['ftp_files_pass'];?>@<?php echo $vars['REMOTE_FTP']['ftp_files_host'];?>:2082/frontend/rvblue/index.html" target="_blank">CPANEL</a> | 
<a href="http://<?php echo $vars['REMOTE_FTP']['ftp_files_user'];?>:<?php echo $vars['REMOTE_FTP']['ftp_files_pass'];?>@<?php echo $vars['REMOTE_FTP']['ftp_files_host'];?>:2082/frontend/rvblue/sql/managedbs.html" target="_blank">DATABASE</a> | 
<a href="http://<?php echo $vars['REMOTE_FTP']['ftp_files_user'];?>:<?php echo $vars['REMOTE_FTP']['ftp_files_pass'];?>@<?php echo $vars['REMOTE_FTP']['ftp_files_host'];?>:2082/frontend/rvblue/cron/index.html" target="_blank">CRON</a> | 
<a href="http://<?php echo $vars['REMOTE_FTP']['ftp_files_user'];?>:<?php echo $vars['REMOTE_FTP']['ftp_files_pass'];?>@<?php echo $vars['REMOTE_FTP']['ftp_files_host'];?>:2082/3rdparty/phpMyAdmin/index.php?lang=en-utf-8" target="_blank">PHPMYADMIN</a> 
</li>
<li><a href="http://templates.hostgator.com/" target="_blank">TEMPLATES HOSTGATOR</a></li>
<li>TENDENCIAS MUNDIALES EN EL MUNDO DE ANUCIONES :  http://adage.com/</li>

<li>para buscar MP3 ( "michael jackson" intitle:index.of mp3 -html -htm -php -asp -txt -pls )</li>
</ul>
<div class='cuadro_codigo bloque'>
<pre>

/////////////////////////
Cron Job, cada 15 minutos
/////////////////////////

*/15		*		*		*		*

cd /home/<?php echo $vars['REMOTE_FTP']['ftp_files_user'];?>/public_html/panel/base2/; php hilo_de_envio_launch.php

</pre>
</div>

<div class='cuadro_codigo bloque'>
<pre>
1

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
I need the MX of the account <?php echo $vars['REMOTE_FTP']['ftp_files_host'];?> set
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

Hi, I need the MX of the account <?php echo $vars['REMOTE_FTP']['ftp_files_host'];?> set

ASPMX.L.GOOGLE.COM. 10 
ALT1.ASPMX.L.GOOGLE.COM. 20 
ALT2.ASPMX.L.GOOGLE.COM. 20 
ASPMX2.GOOGLEMAIL.COM. 30 
ASPMX3.GOOGLEMAIL.COM. 30 
ASPMX4.GOOGLEMAIL.COM. 30 
ASPMX5.GOOGLEMAIL.COM. 30

Would you do this action please. I confirm that I want yout do it please.

Thanks for your help



2

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Please review and fix the MX of the account <?php echo $vars['REMOTE_FTP']['ftp_files_host'];?>, I think they may be wrong\
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

I need the MX of the account <?php echo $vars['REMOTE_FTP']['ftp_files_host'];?> set

ASPMX.L.GOOGLE.COM. 10 
ALT1.ASPMX.L.GOOGLE.COM. 20 
ALT2.ASPMX.L.GOOGLE.COM. 20 
ASPMX2.GOOGLEMAIL.COM. 30 
ASPMX3.GOOGLEMAIL.COM. 30 
ASPMX4.GOOGLEMAIL.COM. 30 
ASPMX5.GOOGLEMAIL.COM. 30

Would you do this action please. I confirm that I want yout do it please.



3
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
I need to Load the modules mod_expires and mod_rewrite for the account <?php echo $vars['REMOTE_FTP']['ftp_files_host'];?>

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

Hi I need to Load the modules mod_expires and mod_rewrite for the account <?php echo $vars['REMOTE_FTP']['ftp_files_host'];?>

Would you do this action please.

I would like to active this modules for all my accounts, Is it posible? 

Thank you


</pre>

</div>

<div class='cuadro_codigo bloque'>
<pre>

ESTRUCTURA WEB
--------------

COMMON:
    M: common.php
    T: common/[head.php, header_pre.php, header.php, menu.php, footer.php, footer_after.php]    
FORMULARIOS:
	M: pagina-formulario.php ->formularios/formularios.php -> formularios/[contacto.php, recomendar.php, pedido.php, registro.php, login.php, cerrar_sesion.php]
    T: formularios/[contacto.php, recomendar.php, pedido.php, registro.php, login.php]
APP:
	M: pagina-app.php -> app/[ carrito.php ]
    T: pagina-app.php -> app/[ carrito.php ]
ITEMS:
	M: pagina-items.php -> items/[ productos.php, categorias.php, usuarios.php ]
    T: pagina-items.php -> items/[ productos.php, categorias.php, usuarios.php ]
ITEM:
	M: pagina-items.php -> items/[ productos.php ]
    T: pagina-items.php -> items/[ productos.php ]
USER:
	M: pagina-user.php
BLOQUES:
	M: bloques/[ ]
    T: bloques/[ ]
ERROR:
    M: pagina-error.php->error/[main-error.php]
    T: pagina-error.php->error/[main-error.php]




CSS
---

-RESET
-LAYOUT
    body
        #div_allcontent
            #div_contenedor
                .contenido_principal
                    #div_header_pre
                        #contenido_margen
                        div_header
                        div_items_main
                        div_footer
-LIBS
	margenes
    div_main
    div_left
    div_right        
    div_barra
    div_status
    div_linea
    div_fila
    div_columna
    div_bloque
    cuadros
    mensajes [ mensaje_info, mensaje_exito, mensaje_alerta, mensaje_error ]
	links [ .fuerte, .debil, .main, .icos ]
    icos
    FORMULARIOS
    	upload
    BLOQUES
    	slider
        intro        

-COMMON
    PRE_HEADER    
    HEADER
    FOOTER
    FOOTER_AFTER
    MENU


-PAGINA-BLOQUES-FORMULARIOS [ login, registro, publicar-anuncio-1, publicar-anuncio-2, recomendar, consulta ]
-PAGINA-APP [ home, carrito ]
-PAGINA-ITEMS [ categorias, productos ]
-PAGINA-ITEM [ productos ]
-BLOQUES [ ofertas, recomendados, SLIDESHOWS ]




                    
</pre>
</div>

<div class='cuadro_codigo bloque'>
<pre>

RECOMENDACIONES SEO según

http://websitegrader.com

1. Registrarse en DMOZ
http://www.dmoz.com/

2. Registrase en 
http://dir.yahoo.com/

3. Registrase en del.icio.us
http://del.icio.us/

4. Digg
http://www.digg.com/

</pre>
</div>

<div class='cuadro_codigo bloque'>
<pre>
-MYSL: Crear BD (  NOMBRE_panel), Usuario de BD (u: NOMBRE_guillermo, p:lozan159357) y asociarlos "antes de todo".
-Versión ideal de PHP 5.2.9 ( pero se ha comprobado que en 5.2.8 funciona)
-Configurar campos y tablas en /config/tablas.php
-Las variables generales, FTP, MYSQL están en /config/config.ini
-Todos los archivos se crean dentro de la carpeta /custom
-Si se trata de un servidor ajeno, habilitar PERMISOS_ESPECIALES=1
MUCHOS EXITOS!!!
</pre>
</div>

<div class='cuadro_codigo bloque'>
<pre>
Mision:
-Pensar bien el enunciado de misión
-la clave del compromiso es la participación
</pre>
</div>

<div class='cuadro_codigo bloque'>
<pre>
Padre Rico:

-LAS PERSONAS DETERMINAN SUS VIDAS POR SUS PENSAMIENTOS
-Soy un hombre rico y los ricos no hacen esto
-El dinero es poder
-Hágalo Fácil
-Si tengo que trabajar no es un negocio, se vuelve un trabajo
-Tener un cuidado en diferencias entre activos y pasivos
-Comprar los lujos al final
-Construir primero la columna de activos
-Cuando un dólar entra piensa en él como un empleado
-El deseo es aprendido
-Buscar una oportunidad creada por el mercado
DESEOS
-no quiero trabajar toda mi vida
-no me gusta ser un empleado
-quiero ser libre para viajar por el mundo viviendo el estilo de vida que me gusta
-quiero tener una familia y que tenga el estilo de vida que me gusta
-quiero tener una bella mujer, y tener lindos hijos
-quiero ser joven cuando haga esto
-quiero ser libre
-quiero controlar mi tiempo y mi vida
-quiero que el dinero trabaje para mi
ELIJO SER RICO
ESCOJA A SUS AMIGOS
AUTODISCIPLINA
NO COMPRAR LUJOS A CREDITO
LOS HEROES HACEN QUE LAS COSAS PAREZCAN FACILES
DAR LO QUE UNO QUIERE RECIBIR Y VOLVERA A RAUDALES
</pre>
</div>

<div class='cuadro_codigo bloque'>
<pre>
Pensamientos:
-Si puedes soñarlo puedes hacerlo
-El verdadero viaje del descubrimiento consiste no en buscar nuevos caminos sinó en tener nuevos ojos
</pre>
</div>

<div class='cuadro_codigo bloque'>
<pre>
Proximamente:

--importar BD con datos remoto->local: borrar BD local, cargar BD remota. [ ya está ]
--startup del panel: creacion de directorios/ reseteo de memoria / creacion de todas las tablas y todos los archivos ( ya está )
--startup maquetado: que se creen todos los archivos necesarios para la parte publica. [ ya está ]
-Videos de youtube: que al click, se reproduzcan en flotante.
-Mejorar las imagenes en el listado: que al click se puedan ver las imagenes en grande, flotante. [ ya está ]
-Agregar buscador en el listado
-Agregar campos:
    *geoposición
    *wyswyg [ ya está ]
    *radio buton ( igual a combo ) [ ya está ]
    *checkbox 
-Editar en formulario completo [ ya está ]
-campos sincronizados
-tablas de relaciones

</pre>
</div>

<div class='cuadro_codigo bloque'>
<pre>
Paquete de Negocio:

-Website dinámico 2.0 orientado a exhibición y venta de productos
-Diseño y desarrollo que se ajusta a las necesidades específicas de su empresa o negocio
-Catálogo productos organizado en categorías y subcategorías
-Buscador de productos
-Página de cada productos con Detalles y Fotos
-Interactividad con clientes
	Comentarios y Calificación del producto
    Publicación de producto en Facebook / en Twitter
-Administrador de contenidos, categorias y productos
-Carrito de compra con orden de pedido
-Posicionamiento en buscadores
-Dominio y Hosting ( 500 Mb / 5 Gb de transferencia )
-50 Cuentas de correo de 7 Gb ( gmail )

</pre>
</div>


<div class='cuadro_codigo bloque'>
<pre>

http://theproc.es/blogs/249/disenar

Estructura web:


</pre>
</div>
<div class='cuadro_codigo bloque'>
<pre>

Negocio
Misión
Visión

 MVC
----
-Modelo de Datos ( Mysql )
-Controlador ( lógica: php, funciones, librerias, proceso de imagenes )
-Vista: ( php,html,javascript,css )
	-Diseño (
    -Usabilidad ( ajax, organización )
-Backoffice
-SEO
	*TITULOS
    *URLS
    *HTML SEMANTICO
    *TAGS ( falta )
    *RSS ( falta )
    *SITEMAP
    *MAPA WEB ( falta )
	http://websitegrader.com/
    
-DOMINIO
	Registrar el dominio para varios años

-Moviles

</pre>
</div>
<div class='cuadro_codigo bloque'>
<pre>
COMPRESION OFUSCASION

archivo para compresión yuicompressor-2.4.2.jar

>java -jar yuicompressor-2.4.2.jar --type css -o file_salida file_entrada
>java -jar yuicompressor-2.4.2.jar --type js -o file_salida file_entrada

--nomunge (  Minify only, do not obfuscate )

</pre>
</div>
<div class='cuadro_codigo bloque'>
<pre>

SEO
---


-Títulos
	*El título debe incluir las PALABRAS CLAVES
    *El título debe tener menos de 65 caracteres
    *El título no debe de tener mas de 15 palabras
	*El título debe ser único
    
	*Usar palabras claves, que describa bien el contenido, buscar el enganche
    *Sé creativo, Sé informativo, Escribe el título al final
-Meta Description
	*Meta Description debe incluir las PALABRAS CLAVES
    *Meta Description no debe tener mas de 150 caracteres
    *Meta Description no debe tener mas de 30 palabras
    *Meta Description debe ser único
-Meta Keywords
	*Meta Keywords debe incluir las PALABRAS CLAVES
    *Use sólo palabras claves que esten incluidas en el contenido de la web
    *No dee tener mas de 10 PALABRAS
    *separadas con comas
    *que esten en minúsculas
-Meta Robots
-Etiquetas
	Usar H1 sólo una vez
    H1 debe incluir las PALABRAS CLAVES
    Usar tambien H2 y H3
-Contenido de página
	Que el contenido sea único
    las imagenes siempre tienen que tener en el atributo ALT la descripción de la
    que primero cargue el contenido luego los sidebars
    que el HTML sea semantico y válido
 -imágenes
    las palabras claves en el contenido deben de estar presentes entre el 5% y 7%
    No poner mas de 100 links en una sola página.
-Dominio
	que el dominio contenga la palabra clave
    no usar caracteresa especiales en el dominio
    usar guiones en lugar de guiones bajos
    el dominio debería tener mas de 2 años
-URLS
	Tratar de manter un Url corto
    No usar parametro dinamicos ( ?uno=dos&tres=cuatro )
    usar guiones para separar palabras
    debe estar en minusculas
    la URL no debe tener mas de 3 niveles
	*Terminacion de Urls sin /, si termina en / la redirigimos a la Url sin /
    *mejor no usar wwww , si la usan redirigir a la url sin www





OPTIMIZACIÓN
------------

* Rule 1 - Make Fewer HTTP Requests
	Si es posible poner todos los css en uno solo
    Todos los js en uno solo
    Todas las imagenes de diseño en una sola ( css sprite )
    Pero es recomendable tener el logo como un IMG y como una CSS BACKGROUND
* Rule 2 - Use a Content Delivery Network
	CDN es un servidor aparte de alto rendimiento especial para el contenido estativo, imagenes, css, js, video ( hay que profundizar en el tema )
* Rule 3 - Add an Expires Header
	Configar en el .htaccess, usando él módulo mod_expires ( ya lo tengo )
* Rule 4 - Gzip Components
	Hay muchas formas de hacerlo, una es usar el módulo mod_deflates ( pero aun )
    Otra es usar en el .htaccess compresión gzip de php , e incluso funciona para el js y el css, si se declaran como phps, ( ya lo tengo, pero necesita ponerle cabecera css al css )
* Rule 5 - Put Stylesheets at the Top
	Esto siempre se hace
* Rule 6 - Put Scripts at the Bottom
	Esto no creo que lo haga, por funcionalidad
* Rule 7 - Avoid CSS Expressions
	Expresiones CSS como por ejemplo lo del FIX PNG
* Rule 8 - Make JavaScript and CSS External 
	Hacer JS y CSS archivos aparte ( ya se hace )
* Rule 9 - Reduce DNS Lookups
	Evitar chekear muchos dominios
* Rule 10 - Minify JavaScript
	Poco Javascript
* Rule 11 - Avoid Redirects
	Evitar redireccionar
* Rule 12 - Remove Duplicate Scripts
	Evitar duplicar codigo JS
* Rule 13 - Configure ETags
	esto es tan solo poner
    	Etags none
    en el .htaccess
* Rule 14 - Make AJAX Cacheable
	esto no lo veo recomendale



</pre>
</div>
