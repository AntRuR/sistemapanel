<?php //á

//unset($_SESSION['publicar']);
//prin($_SESSION);
//prin($_COOKIE);
//prin($_GET);


/**********************************************/
//////////////////  GET  ///////////////////////
/**********************************************/



/**********************************************/
//////////////////GLOBALS//////////////////////
/**********************************************/

include("lib/class.autokeyword.php");
include("lib/include.php");

/**********************************************/
///////////////HEAD INCLUDES////////////////////
/**********************************************/

$INCLUDE['version']="?v=71";

$HEAD['INCLUDE']['version']=$INCLUDE['version'];

//$HEAD['INCLUDE']['anaytics_code']='UA-11630337-1';

$HEAD['INCLUDES']['ico'][]='img/favicon.ico';
$HEAD['INCLUDES']['css']['base']='css/css.css';
$HEAD['INCLUDES']['js'][]='js/mootools-1.2.3-core-yc.js';
$HEAD['INCLUDES']['js'][]='js/js.js';

$HEAD['INCLUDES']['js'][]='js/swfobject.js';

$HEAD['INCLUDES']['script'][]="var clear='".$SERVER['BASE'].THEME_PATH."img/clear.gif'";

if($SERVER['browser']=='IE6'){
$HEAD['INCLUDES']['js'][]='js/unitpngfix.js';
}
//web_render_general_config();

/**********************************************/
//////////////////configuraciones///////////////
/***********************************************

body
#div_allcontent
	#div_contenedor
		.contenido_principal
			#div_header_pre ( opcional )
				#contenido_margen
				#div_header
				.menu_main
				#div_items_main
				#div_footer
*/




//$HEAD['INCLUDES']['style'][]='html, body {background:#E5E5E5 url('.THEME_PATH.'img/common_bg.gif) repeat 0px 0px;}';
//$HEAD['INCLUDES']['style'][]='html, body {background:#C4C0BF url('.$SERVER['BASE'].THEME_PATH.'img/bg.jpg) no-repeat -262px 0px;}';
$HEAD['INCLUDES']['style'][]='html, body {background:#E9E7FC;}';
$HEAD['INCLUDES']['style'][]='#div_allcontent { width: 876px; }';
$HEAD['INCLUDES']['style'][]='.contenido_principal {background:none;}';
$HEAD['INCLUDES']['style'][]='#contenido_margen {margin: 0px;}';

/*HEADER*/
$HEAD['INCLUDES']['style'][]='#div_header {width:100%; height:199px; background:transparent url('.$SERVER['BASE'].THEME_PATH.'img/header_bg.gif) repeat-x scroll left bottom;  }';


/*LOGO*/
$LOGO='logo/logo4.jpg';
//$HEAD['INCLUDES']['style'][]='#header_logo {width:143px; height:59px; left:0px; top:0px; background: transparent url(../img/'.$LOGO.') repeat-x scroll;}';
$HEAD['INCLUDES']['style'][]='#header_logo {width:143px; height:59px; left:20px; top:50px; background: none; z-index:2;}';
$COMMON['path_logo']=$SERVER['BASE'].THEME_PATH.'img/'.$LOGO;

web_render_swf("banner_kkiery.swf","header_elemento_1","elemento_header","876x161");


/*canvas*/
$HEAD['INCLUDES']['style'][]='	.div_canvas { 	background:none;	border:none;  }';
/*left*/
$HEAD['INCLUDES']['style'][]='	.div_left { width:200px; margin-right:10px; }';
/*main*/
$HEAD['INCLUDES']['style'][]='	.div_main { width:655px; }';
/*right*/
$HEAD['INCLUDES']['style'][]='	.div_right { width:0px; display:none; }';

/*sombras*/
$HEAD['INCLUDES']['style'][]='	.div_sombra_left, .div_sombra_right { top:0px; display:none; }';







/*LINKS*/		
$COMMON['url_home']=procesar_url('index.php?modulo=pagina-app&tab=home');
$COMMON['url_publicar']=procesar_url('index.php?modulo=pagina-formulario&tab=publicar-anuncio-1'.web_follow_url(array('id_departamento','id_provincia','id_distrito')));
$COMMON['url_pedido']=procesar_url('index.php?modulo=pagina-formulario&tab=carrito');
$COMMON['url_login']=procesar_url('index.php?modulo=pagina-formulario&tab=login');
$COMMON['url_registro']=procesar_url('index.php?modulo=pagina-formulario&tab=registro');
$COMMON['url_olvido_clave']=procesar_url('index.php?modulo=pagina-formulario&tab=olvido_clave');
$COMMON['url_publicar-2']=procesar_url('index.php?modulo=pagina-formulario&tab=publicar-anuncio-2');
$COMMON['url_carrito']=procesar_url('index.php?modulo=pagina-app&tab=carrito');


/*JAVASCRIPT*/
$HEAD['INCLUDES']['script'][]="var BASE='".$SERVER['BASE']."'";
$HEAD['INCLUDES']['script'][]="var MONEDA='".$COMMON['datos_root']['simbolo_moneda']."'";
$HEAD['INCLUDES']['script'][]="var LINK_BUSQUEDA='".procesar_url('index.php?modulo=pagin-items&tab=productos&buscar=')."'";
$HEAD['INCLUDES']['script'][]="var CARRITO_PAGINA='".procesar_url('index.php?modulo=pagina-app&tab=carrito')."'";
$HEAD['INCLUDES']['script'][]="var CARRITO_ENVIAR='".procesar_url('index.php?modulo=pagina-formulario&tab=carrito')."'";		


/*STYLES COMUNES*/

/*main*/
$HEAD['INCLUDES']['css'][]='css/bloques/bloque_cuadro_6/css.css';
/*carrito*/
$HEAD['INCLUDES']['css'][]='css/carritos/carrito_1/css.css';
$HEAD['INCLUDES']['css'][]='css/carritos/carrito_2/css.css';

/**********************************************/
//////////////////header.php////////////////////
/**********************************************/

$COMMON['header_info'] = "
<span class='ico ico_mobile'>".$COMMON['datos']['nextel_1']."</span>
<span class='ico ico_phone'>".$COMMON['datos']['telefono_1']." / ".$COMMON['datos']['telefono_2']."</span>
<a href='mailto:".$COMMON['datos']['email_ventas']."' class='ico ico_email'>".$COMMON['datos']['email_ventas']."</a>
";

$COMMON['categorias'] = select(
        "id,nombre"
        ,"productos_grupos"
        ,"where 1 and  visibilidad='1' order by id asc limit 0,100"
        ,0
		);

/*
///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////
*/


/**********************************************/
///////////////////menu.php/////////////////////
/**********************************************/


$HEAD['INCLUDES']['css'][]='css/menus/menu_main/css.css';


$COMMON['menu']=web_procesar_menu(
							array(
								array(
									'url'=>'index.php?modulo=pagina-app&tab=home'
									,'label'=>$lang["home"]
								)
								,array(
									'url'=>'index.php?modulo=pagina-app&tab=pages&id=nosotros'
									,'label'=>$lang["nosotros"]
								)
								,array(
									'url'=>'index.php?modulo=pagina-app&tab=pages&id=servicios'
									,'label'=>$lang["servicios"]
								)
								/*								
								,array(
									'url'=>'index.php?modulo=pagina-items&tab=productos'
									,'label'=>$lang["catalogo"]
								)
								*/
								,array(
									'url'=>'index.php?modulo=pagina-items&tab=productos'
									,'label'=>$lang["articulos_publicitarios"]									
								)
								,array(
									'url'=>'index.php?modulo=pagina-app&tab=faqs'
									,'label'=>$lang["preguntas_frecuentes"]
								)																																
								,array(
									'url'=>'index.php?modulo=pagina-formulario&tab=contacto' //contacto
									,'label'=>$lang["contacto"]
								)								
	
							),"izquierda"	
						);
				

	
/**********************************************/
//////////////////footer.php////////////////////
/**********************************************/
					

$COMMON['footer_menu']=web_procesar_menu(
							array(
								array(
									'url'=>'index.php?modulo=pagina-static&tab=nosotros'
									,'label'=>"nuestra empresa"
								)
								,array(
									'url'=>'index.php?modulo=pagina-static&tab=privacidad'
									,'label'=>"hoteles"
								)
								,array(
									'url'=>'index.php?modulo=pagina-static&tab=terminos_legales'
									,'label'=>"herramientas para el turista"
								)
								,array(
									'url'=>'index.php?modulo=pagina-formulario&tab=contacto'
									,'label'=>"contáctenos"
								)		
							)	
						);

$COMMON['footer_copyright']="<span id='footer_copyright'>&copy; Copyright 2010 Todos los Derechos Reservados</span>";

//$COMMON['footer_by']="<strong id='footer_by'>by <a href='http://prodiserv.com' title='Diseño y Desarrollo'>prodiserv</a></strong>";

/********************************************/
////////////////// HEAD //////////////////////
/**********************************************/

$HEAD['titulo'] = $COMMON['datos_root']['titulo_web'];

/********************************************/
////////////////// SESSION //////////////////////
/**********************************************/

if($_SESSION['login']['status']==1){
$LOGIN['usuario']="<b>".$_SESSION['login']['nombre']."</b>| <a href='#' >mi cuenta</a> | <a href='#' >mis anuncios</a> | <a href='#' onclick='javascript:cerrar_sesion(\"login\");return false;' rel='nofollow'>salir</a>";
}
/*
if(isset($_SESSION['publicar']['usuario_temp'])){
$STATUS='Hay un anuncio pendiente de publicación (<a class="main" href="'.$COMMON['url_publicar-2'].'">editar</a>). Para terminar de publicar debe <a class="main" href="'.$COMMON['url_registro'].'">registrarse</a> o <a class="main" href="'.$COMMON['url_login'].'">iniciar sesión</a>. O puede <a href="#" onclick="javascript:cerrar_sesion(\'publicar\');return false;" rel="nofollow" class="main" >cancelar</a> la publicación';
}
*/

	
/************************************************/
						
?>