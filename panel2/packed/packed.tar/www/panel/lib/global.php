<?php



//error_reporting(0);



date_default_timezone_set('America/New_York');



$vars=parse_ini_file("config/config.ini",true);

//echo "<pre>"; print_r($vars); echo "</pre>";

$vars_global=$vars['GENERAL'];



$UPLOAD_FTP=(isset($vars_global['UPLOAD_FTP']))?$vars_global['UPLOAD_FTP']:1;



extract($vars_global);

if ($_SERVER['SERVER_NAME']=="localhost" or $_SERVER['SERVER_NAME']=="127.0.0.1") {



	$vars['LOCAL']['httpfiles']=($vars['GENERAL']['MODO_LOCAL_ARCHIVOS_REMOTOS']==1)?$vars['REMOTE']['httpfiles']:$vars['LOCAL']['httpfiles'];

	$vars_server=$vars['LOCAL'];

	$vars_server_mysql=$vars['LOCAL_MYSQL'];

	$vars_server_ftp=$vars['LOCAL_FTP'];

	$server_place="LOCAL";	

	$Local=1;

	$SERVER['LOCAL']=1;

	error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING ^ E_DEPRECATED);

	

} else {

	$vars_server=$vars['REMOTE'];

	$vars_server_mysql=$vars['REMOTE_MYSQL'];

	$vars_server_ftp=$vars['REMOTE_FTP'];

	$server_place="REMOTO";

	$Local=0;

	$SERVER['LOCAL']=0;

	error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);

	

}





$parse=parse_url($_SERVER['HTTP_REFERER']);

$SERVER['from_externo']=($parse['host']!=$_SERVER['SERVER_NAME'] )?1:0;

$SERVER['from_interno']=($SERVER['from_externo'])?0:1;



$SERVER['REDIRECT_QUERY_STRING']=$_SERVER['REDIRECT_QUERY_STRING'];

		

/*

$vars_server_local=$vars['LOCAL'];

$vars_server_remoto=$vars['REMOTE'];

$vars_server_ftp_local=$vars['LOCAL_FTP'];

$vars_server_ftp_remoto=$vars['REMOTE_FTP'];

*/

$get_num_vars=0;

foreach($vars as $vars2){

foreach($vars2 as $vars3){

$get_num_vars++;

}

}



extract($vars_server);

extract($vars_server_mysql);

extract($vars_server_ftp);



$HTML_ALL_INICIO    = '

<div id="div_allcontent" >
	<div class="div_sombra_left"></div>
	<div class="div_sombra_right"></div>	
	<div id="div_contenedor" >';		

	

$HTML_MAIN_INICIO   = '

		<div class="contenido_principal"   >';

		

$HTML_MAIN_FIN 		= '

		</div>';		



$HTML_ALL_FIN		= '

	</div>

</div>'; 



$HTML_ESQUINAS_ARRIBA    = '<div class="linea_arriba">

								<div class="arizq"></div>

								<div class="arder"></div>

								<div class="armed"></div>

							</div>';

							

$HTML_ESQUINAS_ABAJO    = '<div class="linea_abajo">

								<div class="abizq"></div>

								<div class="abder"></div>

								<div class="abmed"></div>

							</div>';							



define(HTML_ALL_INICIO,$HTML_ALL_INICIO);

define(HTML_MAIN_INICIO,$HTML_MAIN_INICIO);

define(HTML_MAIN_FIN,$HTML_MAIN_FIN);

define(HTML_ALL_FIN,$HTML_ALL_FIN);



define(CLAV,"26188592614506");



$DEPARTAMENTOS_PERU = array(

							"Amazonas",

							"�ncash",

							"Apur�mac",

							"Arequipa",

							"Ayacucho",

							"Cajamarca",

							"Callao",

							"Cusco",

							"Huancavelica",

							"Hu�nuco",

							"Ica",

							"Jun�n",

							"La Libertad",

							"Lambayeque	",

							"Lima",

							"Loreto",

							"Madre de Dios",

							"Moquegua",

							"Pasco",

							"Piura",

							"Puno",

							"San Mart�n",

							"Tacna",

							"Tumbes"

							);



$script_A = explode("/",$_SERVER['REQUEST_URI']);

$url_script=$script_A[sizeof($script_A)-1];



$script_A = explode("/",$_SERVER['SCRIPT_FILENAME']);

$file_script=$script_A[sizeof($script_A)-1];



$script_A = explode("/",$_SERVER['PHP_SELF']);

unset($script_A[sizeof($script_A)-1]);

$dir_script=implode("/",$script_A);



$SERVER['URL']=$url_script;

$SERVER['ARCHIVO']=$file_script;

$SERVER['BASE']="http://".$_SERVER['HTTP_HOST'].$dir_script."/";



$BGCOLOR_DESARROLLO="#FFEEE0";



$LOREN_IPSUM="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquid ex ea commodi consequat. Quis aute iure reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint obcaecat cupiditat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquid ex ea commodi consequat. Quis aute iure reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint obcaecat cupiditat non proident, s";





$LOREN_IPSUM_HTML="<p>$LOREN_IPSUM</p><p>$LOREN_IPSUM</p><p>$LOREN_IPSUM</p>";



$limite_campos_en_lista=5;





$STOPWORDS=array();

$STOPWORDS_=file("stopwords.txt");

foreach($STOPWORDS_ as $stop){

$STOPWORDS[]=trim($stop);

}

function get_browser_()

{

	global $_SERVER;

	$user_agent=$_SERVER['HTTP_USER_AGENT'];

	$browsers = array(

		'Opera' => 'Opera',

		'Firefox'=> '(Firebird)|(Firefox)',

		'Galeon' => 'Galeon',

		'Mozilla'=>'Gecko',

		'MyIE'=>'MyIE',

		'Lynx' => 'Lynx',

		'Netscape' => '(Mozilla/4\.75)|(Netscape6)|(Mozilla/4\.08)|(Mozilla/4\.5)|(Mozilla/4\.6)|(Mozilla/4\.79)',

		'Konqueror'=>'Konqueror',

		'SearchBot' => '(nuhk)|(Googlebot)|(Yammybot)|(Openbot)|(Slurp/cat)|(msnbot)|(ia_archiver)',

		'IE8' => '(MSIE 8\.[0-9]+)',

		'IE7' => '(MSIE 7\.[0-9]+)',

		'IE6' => '(MSIE 6\.[0-9]+)',

		'IE5' => '(MSIE 5\.[0-9]+)',

		'IE4' => '(MSIE 4\.[0-9]+)',

	);

 

	foreach($browsers as $browser=>$pattern)

	{

		if (eregi($pattern, $user_agent))

			return $browser;

	}

	return 'Unknown';

	

}



$SERVER['browser']=get_browser_();



?>