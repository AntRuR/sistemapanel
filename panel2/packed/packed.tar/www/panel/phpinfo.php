<?php //á

phpinfo();
?>