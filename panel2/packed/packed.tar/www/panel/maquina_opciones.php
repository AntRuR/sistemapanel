<style>
a.links_menu { padding:0 2px; margin:2px 2px 0 0; float:right; color:#FFFF99; }
</style>
<?php 

$tablas_creadas=array();

$sql = "show tables";
$result=mysql_query($sql,$link);
$total=mysql_num_rows($result);
if($total>0){
	while ($row = mysql_fetch_row($result)){
			$tablas_creadas[] = $row[0];
	}
}

$tblsinc=array();
$cam='sincromysql';
foreach($objeto_tabla as $ot){
if( ($saved[$ot['me']][$cam]==1) and (in_array($ot['tabla'],$tablas_creadas)) ){ $tblsinc[]=$ot['tabla']; }
}
			
$tablassincro="&tablas=".implode(",",$tblsinc);


?>
<div class="cabecera bloque" style="background-color:#888888;margin-top:0px; padding:4px 0; width:100%;">

<a href='#' rel='nofollow' class="links_menu" onclick="javascript:edit_init('GENERAL','mostrar_toolbars','0');return false;">cerrar toolbar</a>
<a href="maquina.php?accion=borrarcookie" class="links_menu" >[salir]</a>    

<?php if($Local=='1'){ ?>

<?php 
//if($vars['INTERNO']['ID_PROYECTO']!="0"){ 
if(1){ ?>

	<?php if($_SESSION['edicionweb']=='1'){ ?>
    <a href="maquina.php?edicionweb=0" class="links_menu" style=" background-color:#990000; color:#FFFFFF; ">APAGAR EDICION WEB</a>
	<?php } else { ?>
    <a href="maquina.php?edicionweb=1" class="links_menu" style=" background-color:#003300; color:#FFFFFF; ">ENCENDER EDICION WEB</a>
	<?php } ?>

    <a href="maquina.php?accion=bajarconfig" class="links_menu" style="color:#FFFFFF;">&dArr;bajar config</a>
    <a href="maquina.php?accion=subirconfig" class="links_menu" style="color:#FFFFFF;">&uArr;subir config</a>
    <a href="<?php echo str_replace("[http]","http://",str_replace("//","/",str_replace("http://","[http]",$vars['REMOTE']['httpfiles'])."/".$vars['GENERAL']['DIRECTORIO_PANEL']));?>" class="links_menu" style="color:#FF0000; background-color:#000000;" target="_blank">Panel Remoto</a>
    <a href="maquina.php?accion=updatepanel" class="links_menu" style="color:#000000; background-color:#66FFCC; ">&uArr;subir CUSTOM</a>
    <a href="maquina.php?accion=alllistado#anfiles" class="links_menu" style="background-color:#FF0000; color:#FFFF99; font-weight:bold; text-transform:uppercase; ">Listar todos los archivos</a>
    <a href="maquina.php?accion=updatecode" class="links_menu" style="background-color:#FFFF99;color:#000000;">Actualizar Fuente</a>
    <?php if($vars['INTERNO']['ID_PROYECTO']!="0"){ ?>
    <?php if($vars['GENERAL']['IMPORTARDB']!='0'){?>
        <span style="background-color:#006600; color:#FFF; float:right; padding:0 2px;" >
        <input type="text" id="importDBdominio" style="width:50px; float:left;" />
        <a href="#" onclick="javascript:location.href=($v('importDBdominio')=='')?'maquina.php?accion=importdb<?php echo $tablassincro;?>':'maquina.php?accion=importdb<?php echo $tablassincro;?>&domain='+$v('importDBdominio');return false;" rel="nofollow" class="links_menu" style="background-color:#00FF00; color:#FFF;" >Import DB</a>
        </span>
    <?php } ?>
    <?php } ?>
        
    <?php if($vars['GENERAL']['EXPORTARDB']!='0'){?>
        <a href="maquina.php?accion=exportdb" class="links_menu" style="background-color:#003399; color:#FFFFFF;" >Export DB</a>
    <?php } ?>

<?php } ?>



<?php } ?>
<a href="maquina.php?tab=documentos" class="links_menu" >documentos</a>
<a href="maquina.php?tab=estadisticas" class="links_menu" >estadísticas</a>
<a href="maquina.php?accion=borrarcustom" class="links_menu" >Borrar archivos de custom</a>
<a href="maquina.php?accion=borrarmemory" class="links_menu" >Reset archivo de memoria</a>
<a href="maquina.php?config=edit" class="links_menu" style=" background-color:#FFFFFF; color:#000000;">Configuraciones (<?php echo $get_num_vars;?>)</a>        
<a href="maquina.php?ver=phpinfo" class="links_menu" >Phpinfo</a>        
<a href="<?php echo $httpfiles; ?>:2082/3rdparty/phpMyAdmin/index.php?lang=es-utf-8" class="links_menu" target="_blank" >Phpmyadmin</a>
<a href="removerbom/remover_bom.php" target="_blank" class="links_menu"  >Remover BOM</a>  &nbsp;

</div>
<?php /*
<a style="position:absolute; text-decoration:none; top:1px; right:1px; font-family:verdana; font-weight:bold;
background-color:#000000; color:#FFFFFF;">X</a>
*/ ?>
<div>
<?php
/*
	foreach($objeto_tabla as $ot){
	
		echo '<a href="maquina.php?me='.$ot['me'].'" class="objetos" style="';
		echo ($_GET['me']==$ot['me'])?" color:#000;background-color:#FFFF99;":"";
		echo '">'.$ot['tabla'].'</a>';
		
	}
*/	
?>
</div>