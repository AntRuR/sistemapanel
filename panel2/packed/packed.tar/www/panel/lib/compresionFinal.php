<?php

print_gzipped_page();

?>