
        <div class="formulario" style="position:relative;">

          	<div class="saving"  id="<?php echo $tbf?>_load" style="display:none;top:-30px;left:0px;" >cargando...</div>
        
        	<?php if(strpos($_SERVER['SCRIPT_NAME'], "login.php")===false){ ?>
        	<h1 style=" display:none;" class="titulo_formulario" 
            id="titulo_editar_<?php echo $datos_tabla['me']?>" >
            
			<a style=" float:right; margin-right:18px; font-size:12px; " href="#" rel="nofollow" onclick="javascript:<?php echo $tbf?>_ajax('editar_completo_cancelar','');return false;" >Cancelar Editar</a>
            
			<a style=" float:right; margin-right:18px; font-size:12px; " href="#" rel="nofollow" 
onclick="javascript:<?php echo $tbf?>_ajax('guardar_completo',$v('<?php echo $tb?>_id_guardar'));return false;" >Guardar <?php echo ucfirst($datos_tabla['nombre_singular']);?></a>            
            
            Editar <?php echo ucfirst($datos_tabla['nombre_singular']);?>
            
            </h1>
            <h1 class="titulo_formulario" 
            id="titulo_crear_<?php echo $datos_tabla['me']?>">
            Crear <?php echo ucfirst($datos_tabla['nombre_singular']);?>
            </h1>
            <?php } ?>
            
            <?php 
			$DIVISON[2]='width:45%;margin-right:1%;';
			$DIVISON[3]='width:30%;margin-right:1%;';
			$DIVISON[4]='width:18%;margin-right:1%;';
			foreach($tbcampos as $tbcampA){ 
			?>
            <?php
				switch($tbcampA['derecha']){
				case "1":$Derecha="linea_derecha_inicio";break;
				case "2":$Derecha="linea_derecha";break;
				case "3":$Derecha="linea_derecha_espacio";break;
				default :$Derecha=""; break;
				}
                switch($tbcampA['tipo']){ 
                    case "inp": 
                        ?>
                        <div class="linea_form <?php echo $Derecha; ?>">
                            <label for="<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>" ><?php echo $tbcampA['label']?>
                            <?php	if($tbcampA['validacion']=='1'){ ?>*<?php }?></label>
                            <?php
							$maxlength=($tbcampA['size']!='')?$tbcampA['size']:'80';
							$stylewidth=($tbcampA['size']!='')?'width:'. ( $tbcampA['size']*7).'px; ':'';
							?>
                            <input type="text" id="<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>" class="form_input" autocomplete="off" 
                            maxlength="<?php echo $maxlength;?>" 
                            style=" <?php 
							echo ($tbcampA['style'])?$tbcampA['style']:'';							
							echo ($tbcampA['unique'])?'border:1px solid #666666;':'';
							echo $stylewidth;
							?> "
                            value="<?php echo $tbcampA['default']?>"
                            />
                        </div>
                        <?php 
                    break; 
                    case "pas": 
                        ?>
                        <div class="linea_form <?php echo $Derecha; ?>">
                            <label for="<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>" style="height:40px;" ><?php echo $tbcampA['label']?>
                            <?php	if($tbcampA['validacion']=='1'){ ?>*<?php }?></label>
                            <?php
							$maxlength=($tbcampA['size']!='')?$tbcampA['size']:'80';
							$stylewidth=($tbcampA['size']!='')?' style=" width:'. ( $tbcampA['size']*7).'px" ':'';
							?>                  
                            <div><input type="password" id="<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>" class="form_input" autocomplete="off"  
                            maxlength="<?php echo $maxlength;?>" <?php echo $stylewidth;?>                             
                            /></div>
                            <div><input type="password" id="<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>_2" class="form_input" autocomplete="off"  
                            maxlength="<?php echo $maxlength;?>" <?php echo $stylewidth;?>                                                         
                            /></div>
                            
                        </div>
                        <?php 
                    break;
                    case "paslogin": 
                        ?>
                        <div class="linea_form <?php echo $Derecha; ?>">
                            <label for="<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>" style="height:40px;" ><?php echo $tbcampA['label']?>
                            <?php	if($tbcampA['validacion']=='1'){ ?>*<?php }?></label>
                  
                            <div><input type="password" id="<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>" class="form_input" autocomplete="off" 
                            onkeyup=" if(event.keyCode=='13'){ <?php echo $tbf?>_ajax('login',''); } " /></div>
                            
                        </div>
                        <?php 
                    break;					 
                    case "fch":
                        ?>
                        
                        <div class="linea_form <?php echo $Derecha; ?>">
                            <label for="<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>"><?php echo $tbcampA['label']?>
                            <?php	if($tbcampA['validacion']=='1'){ ?>*<?php }?></label>
                            
                  			<span id="<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>_span"></span>
                            <script>
							
								function input_date_<?php echo $tbcampA['campo']?>(id_input,id_span){
									var meses = new Array();
										meses[1]="Enero";
										meses[2]="Febrero";
										meses[3]="Marzo";
										meses[4]="Abril";
										meses[5]="Mayo";
										meses[6]="Junio";
										meses[7]="Julio";
										meses[8]="Agosto";
										meses[9]="Setiembre";
										meses[10]="Octubre";
										meses[11]="Noviembre";
										meses[12]="Diciembre";
										
var html = "<select id='"+id_input+"_d' class='form_input_fecha' onchange='<?php echo $tb?>_<?php echo $tbcampA['campo']?>_change(\""+id_input+"\")' style='width:40px; margin-right:1px;'>";
										html+= "<option></option>";
										for(var i=1; i<=31;i++){
										html+="<option value='"+ ( (i<10)?"0"+i:i) +"'>"+i+"</option>";
										}
										html+= "</select>";
										html+= "<select id='"+id_input+"_m' class='form_input_fecha' onchange='<?php echo $tb?>_<?php echo $tbcampA['campo']?>_change(\""+id_input+"\")' style='width:87px; margin-right:1px;'>";
										html+= "<option></option>";
										for(var i=1; i<=12;i++){
										html+="<option value='"+ ( (i<10)?"0"+i:i) +"'>"+meses[i]+"</option>";
										}										
										html+= "</select>";
										html+= "<select id='"+id_input+"_a' class='form_input_fecha' onchange='<?php echo $tb?>_<?php echo $tbcampA['campo']?>_change(\""+id_input+"\")' style='width:54px; margin-right:1px;'>";
										html+= "<option></option>";
										<?php
										if($tbcampA['rango']){
										list($uuno,$ddos)=explode(",",$tbcampA['rango']);
										$FromYear = date("Y",strtotime($uuno));
										$ToYear = date("Y",strtotime($ddos));										
										} else {
										$FromYear = date("Y")-99;
										$ToYear = date("Y")+1;
										}
										?>
										for(var i=<?php echo $FromYear;?>; i<=<?php echo $ToYear;?>;i++){
										html+="<option value='"+i+"'>"+i+"</option>";
										}										
										html+= "</select>";
										html+= "<input id='"+id_input+"' type='hidden' />";
													
										$(id_span).innerHTML=html;

										
								}
								
								window.addEvent('domready',function(){
                            	input_date_<?php echo $tbcampA['campo']?>('<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>','<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>_span','');								
								<?php if(trim($tbcampA['default'])!=''){ 
								if(trim($tbcampA['default'])=="now()"){ $tbcampA['default']=date("Y-m-d H:i:s"); }
								if(trim($tbcampA['default'])=="tomorrow()"){ $tbcampA['default']=date("Y-m-d H:i:s",strtotime("+1 day")); }
								?>
								$('<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>_d').value='<?php echo substr($tbcampA['default'],8,2);?>';
								$('<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>_m').value='<?php echo substr($tbcampA['default'],5,2);?>';
								$('<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>_a').value='<?php echo substr($tbcampA['default'],0,4);?>';								
								$('<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>').value='<?php echo $tbcampA['default']?>';
								<?php } ?>
								});
								
								function <?php echo $tb?>_<?php echo $tbcampA['campo']?>_change(input){
									var aa=$(input+'_a').value;
									var mm=$(input+'_m').value;
									var dd=$(input+'_d').value;
									$(input).value= (aa==''||mm==''||dd=='')?'':aa+'-'+mm+'-'+dd+' 00:00:00';
								}
								
                            </script>
                            
                        </div>
                        <?php 
                    break; 										
                    case "html": case "txt": case "yot":
						if($tbcampA['tipo']=='html'){
                        ?>
						<script>
                        var mooeditable_<?php echo $tbcampA['campo']?>;
                        </script>                        
                        <?php } ?>
                        <div class="linea_form <?php echo $Derecha; ?>">
                            <label for="<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>" ><?php echo $tbcampA['label']?>
                            <?php	if($tbcampA['validacion']=='1'){ ?>*<?php }?></label>                                                       
                            <textarea  id="<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>" class="form_input" 
                            <?php echo ($tbcampA['style']!='')?' style=" '. str_replace(",",";",$tbcampA['style']) .'" ':'';?> 
                            autocomplete="off" rows="6" 
                            ><?php echo ($tbcampA['tipo']=='html')?(($tbcampA['default']=='')?'<p></p>':$tbcampA['default']):$tbcampA['default'];?></textarea>
                        </div>
                        <?php 
						if($tbcampA['tipo']=='html'){
						?>
						<style type="text/css"> 
						#<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>-mooeditable-container{ float:left; }
                        </style>                        
                        <script>
						window.addEvent('domready', function(){
							//$('<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>').setStyles({'float':'left'});
							mooeditable_<?php echo $tbcampA['campo']?> = $('<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>').mooEditable({
								actions: 'bold italic underline | formatBlock justifyleft justifyright justifycenter justifyfull | insertunorderedlist insertorderedlist indent outdent | undo redo removeformat | createlink unlink | toggleview',
								externalCSS: 'css/Editable.css',
								baseCSS: 'html{ height: 100%; cursor: text; } body{ font-family: arial; font-size:12px; }'								
							});

						});
						</script>
                        <?php
						}
                    break;
                    case "multicom":
						?>
                        <div class="linea_form <?php echo $Derecha; ?>">
                            <label for="<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>" ><?php echo $tbcampA['label']?>
                            <?php	if($tbcampA['validacion']=='1'){ ?>*<?php }?></label>                          
                            <div class="form_input" style="float:left; border:0; background:none;">
                            <?php foreach($opciones_select as $opcccion=>$opcion_select){ ?>
                            <div>
                            <strong><?php echo $opcion_select;?></strong>
                            <input type="checkbox"
                            id="<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>_<?php echo $opcccion;?>"
                            name="<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>"
                            value="<?php echo $opcccion;?>"
                            title="<?php echo $opcccion; ?>"
                            <?php echo ($tbcampA['default']=="$opcccion")?"checked":"";?>
                            onchange="if(this.checked){ $('<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>').value=this.value; } "  />
                            </div>
                            <?php } ?>
                            </div>                            
                        </div>                        
                        <?php
                    break;
                    case "com":
						if($tbcampA['radio']=='1' and is_array($tbcampA['opciones'])){
                        ?>
                        <div class="linea_form <?php echo $Derecha; ?>">
                            <label for="<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>" ><?php echo $tbcampA['label']?>
                            <?php	if($tbcampA['validacion']=='1'){ ?>*<?php }?></label>  
                            <?php
                                $opciones_select=array();
								$iti=(is_array($tbcampA['opciones']))?1:0;
                                $opciones_select=(is_array($tbcampA['opciones']))?$tbcampA['opciones']:explode(",",$tbcampA['opciones']);
                                ?>
                            <div class="form_input" style="float:left; border:0; background:none;">
                            <input  id="<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>" type="hidden" />
                            <?php foreach($opciones_select as $opcccion=>$opcion_select){ ?>
                            <strong><?php echo $opcion_select;?></strong>
                            <input type="radio"
                            id="<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>_<?php echo $opcccion;?>"
                            name="<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>"
                            value="<?php echo $opcccion;?>"
                            title="<?php echo $opcccion; ?>"
                            <?php echo ($tbcampA['default']=="$opcccion")?"checked":"";?>
                            onchange="if(this.checked){ $('<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>').value=this.value; } "  />
                            <?php } ?>
                            </div>                                                      
                        </div>
                        <?php 
						} else {
						?>
                        <div class="linea_form <?php echo $Derecha; ?>">
                            <label for="<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>" ><?php echo $tbcampA['label']?>
                            <?php	if($tbcampA['validacion']=='1'){ ?>*<?php } ?></label>                            
                            <select <?php echo ($tbcampA['style']!='')?' style=" '. $tbcampA['style'].' " ':'';?> id="<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>" class="form_input" >
                                <option selected="selected"></option>
                                <?php
                                $opciones_select=array();
								$iti=(is_array($tbcampA['opciones']))?1:0;
                                $opciones_select=(is_array($tbcampA['opciones']))?$tbcampA['opciones']:explode(",",$tbcampA['opciones']);
                                foreach($opciones_select as $opcccion=>$opcion_select){
								$vvvval=($iti)?fixEncoding($opcccion):fixEncoding($opcion_select);
                                ?>
                                <option value="<?php echo $vvvval;?>" 
								<?php echo ($vvvval==$tbcampA['default'])?"selected":"" ?> 
                                ><?php echo fixEncoding($opcion_select)?></option>
                                <?php
                                }
								?>
                            </select>
                        </div>                        
                        <?php
						}
                    break;												
                    case "hid":
						$GGET=$_GET[str_replace(array("[","]"),array("",""),$tbcampA['default'])];
						$ooop=explode("|",$tbcampA['opciones']);
						$oopciones=select($ooop['0'],$ooop['1'],procesar_dato($ooop['2']));
						if(	$tbcampA['combo']=='1' or $GGET=='' ){						
						?>
                        <div class="linea_form <?php echo $Derecha; ?>">
                            <label for="<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>" ><?php echo $tbcampA['label']?>
                            <?php if($tbcampA['validacion']=='1'){ ?>*<?php }?>
                            </label>
                            <span id="<?php echo $tbcampA['campo']?>_load_combo">
                            <select  id="<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>" class="form_input" 
                            <?php echo ($tbcampA['style']=='')?'':" style='".str_replace(",",";",$tbcampA['style'])."' "?>
                            <?php if($tbcampA['load']!=''){ 
							$looop=explode("||",$tbcampA['load']); ?>
							onchange="cargar_combo('<?php echo $looop[0]?>','<?php echo $looop[1]?>',this.value);"
							<?php }?> >
                            <option selected="selected"></option>
	                            <?php 
								foreach($oopciones as $oooo2){ 
								?>
                                <option <?php echo ($GGET==$oooo2['id'])?"selected":"";?> value="<?php echo $oooo2['id']?>" ><?php echo fixEncoding($oooo2['nombre'])?></option>
                                <?php
                                }
								?>
                            </select>
                            </span>
                        </div>                        
						<?php 
						
						} else {
                        ?>
                        <div class="linea_form <?php echo $Derecha; ?>">
                            <label for="<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>" ><?php echo $tbcampA['label']?>
                            <?php if($tbcampA['validacion']=='1'){ ?>*<?php }?>
                            </label>
                            <span 
                            style='float:left;<?php echo ($tbcampA['style']=='')?'':" ".str_replace(",",";",$tbcampA['style'])?>'>
	                            <?php foreach($oopciones as $oooo2){ if($GGET==$oooo2['id']){ echo $oooo2['nombre']; } } ?>                            
                            </span>
                       </div>                             
                        <input type="hidden" id="<?php echo $tb?>_in_<?php echo $tbcampA['campo']?>" autocomplete="off" 
                        value="<?php echo $GGET;?>" />
                        <?php if($tbcampA['load']!=''){ 
						$looop=explode("||",$tbcampA['load']); ?>
                        <script>
						window.addEvent('domready',function(){ 
							cargar_combo('<?php echo $looop[0]?>','<?php echo $looop[1]?>','<?php echo $GGET;?>');
						});
						</script>	
                        <?php } ?>
                        <?php }
                    break;                    
					case "img":
                        ?>
                        <div class="linea_form <?php echo $Derecha; ?>">                                                    
                            <label><?php echo $tbcampA['label']?>
                            <?php	if($tbcampA['validacion']=='1'){ ?>*<?php }?></label>                            
							<div style="float:left;height:auto;" id="upl_<?php echo $tb?>_<?php echo $tbcampA['campo']?>_0">
                            </div>
                            
                            <script>
							window.addEvent('domready',function(){ 
							$("upl_<?php echo $tb?>_<?php echo $tbcampA['campo']?>_0").innerHTML=render_upload('<?php echo $tb?>','<?php echo $tbcampA['campo']?>','','<?php echo $USU_IMG_DEFAULT;?>'); 
							} );
							</script>
                            
                        </div>
                        <div style="clear:left"></div>
                       					
                        <?php 
                    break;
                ?>                
                
				<?php } ?>
            <?php } ?>
            
            <div class="linea_form" style="height:12px; color:#FF0000;" >
            	<label>&nbsp;</label>
                <span id="error_creacion" style=" visibility:hidden; float:left;">&nbsp;&nbsp;</span>
            </div>
            
            <div class="linea_form" >
                <label>&nbsp;</label>
                	<input type="hidden" id="<?php echo $tb?>_mode" value="insert" />
                	<span id="linea_crear">
                	<?php if($login_proceso=='1'){ ?> 
					<input type="button" id="<?php echo $tb?>_in_submit" class="form_boton_1" value="Entrar" style="float:left;" onclick="<?php echo $tbf?>_ajax('login','');"  />                    
                    <?php } else { ?>
					<input type="button" id="<?php echo $tb?>_in_submit" class="form_boton_1" value="Crear <?php echo $datos_tabla['nombre_singular']?>" style="float:left;" onclick="<?php echo $tbf?>_ajax('insertar','');"  />
                    <?php } ?>
                    
                    <?php 
					if($Open and ($datos_tabla['crear_pruebas']!='0') ){					
					?>
                    
                    <input type="button" id="<?php echo $tb?>_in_submit_prueba" class="form_boton_1" value="Crear <?php echo $datos_tabla['nombre_singular']?> de prueba" style="float:left; padding:0; margin-left:20px; background-color:<?php echo $BGCOLOR_DESARROLLO;?>;color:#000000;" onclick="<?php echo $tbf?>_ajax('insertar_prueba','');"   />
                    
                    <?php 
					} 
					?>
                    </span>
                    
					<span id="linea_grabar" style="display:none;">
                                        
                	<input type="hidden" id="<?php echo $tb?>_id_guardar" />
					<input type="button" id="<?php echo $tb?>_ed_save" class="form_boton_1" value="Guardar <?php echo $datos_tabla['nombre_singular']?>" style="float:left;" 
                    onclick="<?php echo $tbf?>_ajax('guardar_completo',$v('<?php echo $tb?>_id_guardar'))"
                    />
					
                    <input type="button" id="<?php echo $tb?>_ed_cancelar" class="form_boton_1" value="Cancelar" style="float:left; margin-left:20px;" 
                    onclick="<?php echo $tbf?>_ajax('editar_completo_cancelar','')"
                    />       
                    
                    </span>
                                        
            </div>
            &nbsp;
          
            
            